# Pip v0.4 – LLM-Minimaltest

## Zweck
Diese Version ist ein reiner Funktionstest der lokalen Qwen-0.5B-Inferenz auf dem Android-Gerät.

- Qwen2.5-0.5B-Instruct Q4_K_M GGUF
- llama-android 0.1.1
- Kontext 512
- 2 CPU-Threads
- maximal 32 Antwort-Tokens
- 90-Sekunden-Timeout
- kein System-Prompt und kein Memory beim Test

Wenn diese Version auf „Senden“ antwortet, bauen wir danach Pip-Persönlichkeit und Memory wieder Schritt für Schritt ein.
