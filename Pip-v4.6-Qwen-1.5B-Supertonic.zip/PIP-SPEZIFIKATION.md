# Pip v4.6

Qwen2.5 1.5B Instruct Q4_K_M, sherpa-onnx 1.13.7 mit Supertonic 3.

v4.6 reduziert beim Start die LLM-Ressourcen auf 768 Kontext / 2 Threads und fängt JVM-Fehler beim Modell-/TTS-Start ab, damit die Oberfläche nicht wegen einer normalen Java/Kotlin-Exception geschlossen wird.
