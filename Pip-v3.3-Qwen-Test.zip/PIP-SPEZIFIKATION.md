# Pip v0.3

## Jetzt enthalten
- lokale Gemma-3-1B-GGUF-Inferenz über eine vorgefertigte llama.cpp Android AAR
- einmaliger Modell-Download (ca. 806 MB)
- deutscher System-Prompt
- lokale SQLite-Erinnerungen
- Beziehungsstufen
- Android-TTS
- On-device SpeechRecognizer, wenn vom Gerät verfügbar
- VoiceInteractionService-Grundlage

## Noch nicht fertig
- echtes dauerhaftes „Hey Pip“-Wake-Word-Modell
- automatische Wake-Word-Erkennung im VoiceInteractionService
- komfortable Memory-/Beziehungs-Oberfläche
- frei wählbare TTS-Stimmen
- APK wurde in dieser Umgebung nicht kompiliert/testet, weil keine Android-Buildtoolchain vorhanden ist.

Modell:
ggml-org/gemma-3-1b-it-GGUF / gemma-3-1b-it-Q4_K_M.gguf
SHA256: 8ccc5cd1f1b3602548715ae25a66ed73fd5dc68a210412eea643eb20eb75a135
