# Pip v4.9

- Qwen2.5 1.5B Instruct Q4_K_M lokal.
- 6 Threads, 512 Kontext, 64 Antwort-Tokens.
- Natürlichere Pip-Persönlichkeit ohne Standard-KI-Floskeln.
- Lokale Erinnerungen und Beziehungsstufe bleiben aktiv.
- Supertonic 3 F1 (sid 0), Deutsch (`de`), lokal über sherpa-onnx.
- Supertonic wird nach dem Laden des LLM im Hintergrund vorbereitet; Android-TTS bleibt Fallback.
- Supertonic-Expression-Tags werden sparsam genutzt und vor der Anzeige entfernt.
