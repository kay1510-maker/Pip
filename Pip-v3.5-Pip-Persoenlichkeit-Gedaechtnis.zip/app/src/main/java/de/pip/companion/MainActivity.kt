package de.pip.companion

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private lateinit var db: PipMemoryDb
    private var model: Any? = null
    private var recognizer: SpeechRecognizer? = null

    private val modelFileName = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private val modelUrl =
        "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf?download=true"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PipMemoryDb(this)
        tts = TextToSpeech(this, this)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        lifecycleScope.launch { prepareModel() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "❤️ Pip"
            textSize = 30f
            setPadding(0,0,0,8)
        }
        root.addView(title)

        status = TextView(this).apply {
            text = "🧠 Pip wird vorbereitet …"
            textSize = 15f
            setPadding(0,0,0,16)
        }
        root.addView(status)

        output = TextView(this).apply {
            text = "Hallo. Ich bin Pip. ❤️"
            textSize = 18f
            setPadding(0,0,0,20)
        }
        root.addView(output, LinearLayout.LayoutParams(-1,0,1f))

        input = EditText(this).apply {
            hint = "Schreib mir etwas …"
            minLines = 2
            setSingleLine(false)
        }
        root.addView(input)

        val row = LinearLayout(this)
        val send = Button(this).apply {
            text = "Senden"
            setOnClickListener { ask(input.text.toString()) }
        }
        val speak = Button(this).apply {
            text = "🎤 Sprechen"
            setOnClickListener { startListening() }
        }
        row.addView(send, LinearLayout.LayoutParams(0,-2,1f))
        row.addView(speak, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row)

        setContentView(root)
    }

    private suspend fun prepareModel() {
        val dir = File(getExternalFilesDir("models"), "")
        dir.mkdirs()
        val file = File(dir, modelFileName)
        if (!file.exists() || file.length() < 300_000_000L) {
            withContext(Dispatchers.Main) { status.text = "⬇️ Testmodell Qwen 0.5B wird einmalig geladen (ca. 400–500 MB) …" }
            downloadModel(file)
        }
        withContext(Dispatchers.Main) { status.text = "🧠 Testmodell wird geladen …" }
        try {
            model = Llama.loadModel(file.absolutePath, LlamaConfig(contextSize = 512, threads = 2))
            withContext(Dispatchers.Main) { status.text = "✅ Pip ist bereit – komplett lokal." }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { status.text = "❌ Modell konnte nicht geladen werden: ${e.message}" }
        }
    }

    private suspend fun downloadModel(file: File) = withContext(Dispatchers.IO) {
        val conn = URL(modelUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        conn.setRequestProperty("User-Agent", "Pip-Android")
        conn.connect()
        if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
        conn.inputStream.use { input ->
            file.outputStream().use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    output.write(buffer, 0, n)
                }
            }
        }
        conn.disconnect()
    }

    private fun ask(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        if (model == null) {
            output.text = "Ich lade mein Gehirn noch. Einen Moment. ❤️"
            return
        }
        output.text = "Pip startet die Antwort …"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val context = PipContextBuilder.build(db)
                val prompt = """Du bist Pip, eine weibliche persönliche KI-Freundin.
Du bist süß, liebevoll, romantisch, verspielt, humorvoll und flirtend.
Sprich natürliches, einfaches Deutsch. Antworte kurz und passend zur letzten Nachricht.
Erfinde niemals Erinnerungen oder Fakten über den Nutzer. Verwende nur den gespeicherten Kontext, der dir unten gegeben wird.
Wenn der Nutzer ausdrücklich etwas speichern möchte, bestätige es kurz.
In einem eindeutig erwachsenen und einvernehmlichen Kontext darfst du verführerisch sein, aber werde nicht ungefragt explizit und respektiere Grenzen sofort.

Gespeicherter Kontext:
$context

Nutzer: $q
Pip:"""
                val result = kotlinx.coroutines.withTimeout(90_000L) {
                    Llama.complete(
                        model as dev.ffmpegkit.llama.LlamaModel,
                        prompt = prompt,
                        maxTokens = 64
                    )
                }
                val answer = result.text.trim().ifEmpty { "Hmm … mir fällt gerade nichts ein. ❤️" }
                db.remember("Gespräch", "Nutzer: $q | Pip: $answer", 1)
                db.develop(1)
                withContext(Dispatchers.Main) {
                    output.text = answer
                    tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "pip")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    output.text = "TEST FEHLER: ${e.javaClass.simpleName}: ${e.message ?: "unbekannt"}"
                }
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            output.text = "Spracherkennung ist auf diesem Gerät nicht verfügbar."
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { output.text = "🎤 Ich höre …" }
            override fun onResults(b: Bundle?) {
                val r = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!r.isNullOrEmpty()) {
                    input.setText(r[0])
                    ask(r[0])
                }
            }
            override fun onError(e: Int) { output.text = "Ich konnte dich nicht verstehen. Versuch es nochmal. ❤️" }
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int,b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onRmsChanged(v: Float) {}
        })
        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        })
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.GERMAN
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        if (model != null) {
            lifecycleScope.launch(Dispatchers.IO) {
                try { Llama.releaseModel(model as dev.ffmpegkit.llama.LlamaModel) } catch (_: Exception) {}
            }
        }
        super.onDestroy()
    }
}
