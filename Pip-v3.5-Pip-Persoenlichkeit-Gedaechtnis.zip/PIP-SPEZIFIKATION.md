# Pip – v3.5

Diese Version baut auf dem erfolgreichen lokalen Qwen-Minimaltest auf.

Enthalten:
- lokales Qwen 2.5 0.5B GGUF
- kurze deutsche Pip-Persönlichkeit
- lokales Gedächtnis über SQLite
- Beziehungsstufe mit 5 Stufen
- Gespräch wird nach jeder Antwort gespeichert
- Android-Sprachausgabe
- deutsche On-Device-Spracherkennung

Bewusst noch nicht enthalten: Supertonic-3, echtes „Hey Pip“-Wakeword und die spätere Beziehungsoberfläche. Diese kommen erst, wenn die Basis stabil läuft.
