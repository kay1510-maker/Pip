Pip v4.3

- Qwen 2.5 1.5B Instruct Q4_K_M, local GGUF
- Pip personality, memory and relationship logic retained
- Sherpa-ONNX 1.13.7 Supertonic 3 TTS
- Supertonic model files are NOT bundled into the APK
- On first use, the app downloads the 7 public model files (~145 MB total) from Hugging Face into app-private storage
- Subsequent speech is fully local/offline
- Voice style sid=0 (F1 female)
- German language code: de
- Android TTS remains as fallback if Supertonic is unavailable
