Pip v4.0: Qwen2.5 1.5B Instruct Q4_K_M + official Supertonic Android 3.x dependency.
No supertonic-kmp and no GitHub Packages authentication.
Supertonic is invoked locally with German language and attempts female F2; Android TTS is only a fallback.
