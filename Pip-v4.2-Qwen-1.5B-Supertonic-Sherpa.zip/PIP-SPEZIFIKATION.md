# Pip 4.2

- Qwen 2.5 1.5B Instruct Q4_K_M for local chat.
- sherpa-onnx v1.13.7 + Supertonic 3 TTS.
- Supertonic 3 model is downloaded during the GitHub build and packaged into the APK, then copied to app-private storage on first launch.
- Female voice F1 uses Supertonic speaker id 5.
- Android TextToSpeech remains only as fallback.
