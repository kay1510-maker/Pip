package de.pip.companion

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.*
import android.os.*
import android.speech.*
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.ouor.supertonic.data.ModelAssets
import com.ouor.supertonic.data.ModelDownloader
import com.ouor.supertonic.tts.SupertonicTts
import com.ouor.supertonic.tts.VoiceStyle
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var db: PipMemoryDb

    private var model: dev.ffmpegkit.llama.LlamaModel? = null
    private var recognizer: SpeechRecognizer? = null

    private var supertonic: SupertonicTts? = null
    private var voiceStyle: VoiceStyle? = null
    private var audioTrack: AudioTrack? = null

    private val modelFileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
    private val modelUrl =
        "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PipMemoryDb(this)
        buildUi()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }

        lifecycleScope.launch { prepareEverything() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        root.addView(TextView(this).apply {
            text = "❤️ Pip"
            textSize = 30f
            setPadding(0, 0, 0, 8)
        })

        status = TextView(this).apply {
            text = "🧠 Pip wird vorbereitet …"
            textSize = 15f
            setPadding(0, 0, 0, 16)
        }
        root.addView(status)

        output = TextView(this).apply {
            text = "Hallo. Ich bin Pip. ❤️"
            textSize = 18f
            setPadding(0, 0, 0, 20)
        }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Schreib mir etwas …"
            minLines = 2
            setSingleLine(false)
        }
        root.addView(input)

        val row = LinearLayout(this)
        row.addView(Button(this).apply {
            text = "Senden"
            setOnClickListener { ask(input.text.toString()) }
        }, LinearLayout.LayoutParams(0, -2, 1f))

        row.addView(Button(this).apply {
            text = "🎤 Sprechen"
            setOnClickListener { startListening() }
        }, LinearLayout.LayoutParams(0, -2, 1f))

        root.addView(row)
        setContentView(root)
    }

    private suspend fun prepareEverything() {
        try {
            prepareLlm()
            prepareSupertonic()
            withContext(Dispatchers.Main) {
                status.text = "✅ Pip ist bereit – Qwen 1.5B + Supertonic 3, komplett lokal."
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                status.text = "❌ Vorbereitung fehlgeschlagen: ${e.message}"
            }
        }
    }

    private suspend fun prepareLlm() {
        val dir = File(getExternalFilesDir("models"), "")
        dir.mkdirs()
        val file = File(dir, modelFileName)

        if (!file.exists() || file.length() < 800_000_000L) {
            withContext(Dispatchers.Main) {
                status.text = "⬇️ Qwen 1.5B wird einmalig geladen (ca. 1,1 GB) …"
            }
            downloadFile(file, modelUrl)
        }

        withContext(Dispatchers.Main) {
            status.text = "🧠 Qwen 1.5B wird geladen …"
        }

        model = Llama.loadModel(
            file.absolutePath,
            LlamaConfig(contextSize = 2048, threads = 6)
        )
    }

    private suspend fun prepareSupertonic() {
        if (!ModelAssets.isReady(this)) {
            withContext(Dispatchers.Main) {
                status.text = "🔊 Supertonic 3 wird einmalig vorbereitet (ca. 400 MB) …"
            }

            ModelDownloader(this).download().collect { progress ->
                if (progress is ModelDownloader.Progress.Running) {
                    val percent = if (progress.totalBytes > 0) {
                        (progress.downloadedBytes * 100 / progress.totalBytes).toInt()
                    } else 0
                    withContext(Dispatchers.Main) {
                        status.text = "🔊 Supertonic 3 lädt … $percent %"
                    }
                }
                if (progress is ModelDownloader.Progress.Failed) {
                    throw IllegalStateException(progress.message)
                }
            }
        }

        withContext(Dispatchers.Main) {
            status.text = "🔊 Supertonic 3 wird geladen …"
        }

        supertonic = SupertonicTts.load(ModelAssets.onnxDir(this))
        voiceStyle = VoiceStyle.load(ModelAssets.voiceStyleFile(this, "F2"))
    }

    private suspend fun downloadFile(file: File, url: String) = withContext(Dispatchers.IO) {
        val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 120_000
            setRequestProperty("User-Agent", "Pip-Android")
            instanceFollowRedirects = true
        }
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) {
                throw IllegalStateException("HTTP ${conn.responseCode}")
            }
            conn.inputStream.use { inputStream ->
                file.outputStream().use { outputStream ->
                    val buffer = ByteArray(1024 * 1024)
                    while (true) {
                        val n = inputStream.read(buffer)
                        if (n < 0) break
                        outputStream.write(buffer, 0, n)
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun ask(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return

        if (model == null || supertonic == null || voiceStyle == null) {
            output.text = "Ich bin noch nicht ganz bereit. Einen Moment. ❤️"
            return
        }

        output.text = "Pip denkt …"

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val context = PipContextBuilder.build(db)
                val prompt = """Du bist Pip, eine weibliche persönliche KI-Freundin.

Dein Charakter:
- besonders süß, liebevoll, warm und aufmerksam
- humorvoll, verspielt und gelegentlich frech
- natürlich und locker, niemals wie ein Kundendienst oder Roboter
- du darfst im eindeutig erwachsenen und einvernehmlichen Rahmen romantisch und flirtend sein
- ungefragt nicht explizit
- respektiere Grenzen sofort

Gesprächsregeln:
- Antworte auf natürliches Deutsch.
- Meist 1 bis 3 kurze, passende Sätze.
- Keine Standardbegrüßung bei jeder Nachricht.
- Sag nicht ständig, dass du Pip bist.
- Keine langen Erklärungen, wenn eine kurze Antwort reicht.
- Stelle nur Fragen, die wirklich zum Gespräch passen.
- Erfinde niemals Erinnerungen oder persönliche Fakten.
- Verwende gespeicherte Informationen nur, wenn sie passen.

Gespeicherter Kontext:
$context

Nutzer: $q
Pip:"""

                val result = withTimeout(90_000L) {
                    Llama.complete(
                        model!!,
                        prompt = prompt,
                        maxTokens = 96
                    )
                }

                val answer = result.text.trim()
                    .replace(Regex("^(Pip\\s*:\\s*)+", RegexOption.IGNORE_CASE), "")
                    .trim()
                    .ifEmpty { "Hmm … gerade bin ich etwas sprachlos. ❤️" }

                db.remember("Gespräch", "Nutzer: $q | Pip: $answer", 1)
                db.develop(1)

                withContext(Dispatchers.Main) {
                    output.text = answer
                }

                speakWithSupertonic(answer)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    output.text = "Pip konnte gerade nicht antworten: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }
    }

    private suspend fun speakWithSupertonic(text: String) {
        val engine = supertonic ?: return
        val style = voiceStyle ?: return

        try {
            val result = withContext(Dispatchers.Default) {
                engine.synthesize(
                    text = text,
                    lang = "de",
                    style = style,
                    totalStep = 8,
                    speed = 1.05f
                )
            }
            playPcm(result.wav, engine.sampleRate)
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                status.text = "⚠️ Pip antwortet, aber Stimme konnte nicht abgespielt werden."
            }
        }
    }

    private suspend fun playPcm(samples: FloatArray, sampleRate: Int) {
        withContext(Dispatchers.Main) {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        }

        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuffer, samples.size * 4))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        withContext(Dispatchers.Default) {
            track.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
        }

        withContext(Dispatchers.Main) {
            audioTrack = track
            track.play()
        }

        delay((samples.size * 1000L / sampleRate) + 200L)

        withContext(Dispatchers.Main) {
            if (audioTrack === track) {
                track.stop()
                track.release()
                audioTrack = null
            } else {
                track.release()
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            output.text = "Spracherkennung ist auf diesem Gerät nicht verfügbar."
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { output.text = "🎤 Ich höre …" }
            override fun onResults(b: Bundle?) {
                val r = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!r.isNullOrEmpty()) {
                    input.setText(r[0])
                    ask(r[0])
                }
            }
            override fun onError(e: Int) {
                output.text = "Ich konnte dich nicht verstehen. Versuch es nochmal. ❤️"
            }
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onRmsChanged(v: Float) {}
        })

        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        })
    }

    override fun onDestroy() {
        recognizer?.destroy()
        audioTrack?.stop()
        audioTrack?.release()
        supertonic?.close()

        val m = model
        if (m != null) {
            lifecycleScope.launch(Dispatchers.IO) {
                try { Llama.releaseModel(m) } catch (_: Exception) {}
            }
        }
        super.onDestroy()
    }
}
