# Pip v3.6

Stabile Basis auf Qwen 0.5B GGUF. Verbesserte deutsche Pip-Persönlichkeit, natürlichere kurze Antworten und vorsichtigerer Umgang mit gespeicherten Erinnerungen.


## Version 4.1
- Qwen2.5 1.5B Instruct GGUF Q4_K_M
- Supertonic 3 Android engine wird beim GitHub-Actions-Build direkt aus dem öffentlichen Android-Referenzprojekt eingebunden.
- Keine GitHub-Package-Authentifizierung für Supertonic erforderlich.
- Supertonic-Modelle werden auf dem Gerät einmalig aus Hugging Face geladen; danach offline.
