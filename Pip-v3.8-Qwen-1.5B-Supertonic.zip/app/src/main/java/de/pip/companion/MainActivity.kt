package de.pip.companion

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.nedmah.supertonic_kmp.*
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var supertonic: SupertonicTts
    private lateinit var db: PipMemoryDb
    private var model: Any? = null
    private var recognizer: SpeechRecognizer? = null

    private val modelFileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
    private val modelUrl =
        "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PipMemoryDb(this)
        supertonic = SupertonicTts(
            SupertonicConfig(
                storageDir = File(filesDir, "supertonic").absolutePath,
                inferenceSteps = 6,
                defaultLang = "de",
                defaultVoice = SupertonicVoice.F2,
                defaultSpeed = 1.0f
            )
        )
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        lifecycleScope.launch { prepareModel() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "❤️ Pip"
            textSize = 30f
            setPadding(0,0,0,8)
        }
        root.addView(title)

        status = TextView(this).apply {
            text = "🧠 Pip wird vorbereitet …"
            textSize = 15f
            setPadding(0,0,0,16)
        }
        root.addView(status)

        output = TextView(this).apply {
            text = "Hallo. Ich bin Pip. ❤️"
            textSize = 18f
            setPadding(0,0,0,20)
        }
        root.addView(output, LinearLayout.LayoutParams(-1,0,1f))

        input = EditText(this).apply {
            hint = "Schreib mir etwas …"
            minLines = 2
            setSingleLine(false)
        }
        root.addView(input)

        val row = LinearLayout(this)
        val send = Button(this).apply {
            text = "Senden"
            setOnClickListener { ask(input.text.toString()) }
        }
        val speak = Button(this).apply {
            text = "🎤 Sprechen"
            setOnClickListener { startListening() }
        }
        row.addView(send, LinearLayout.LayoutParams(0,-2,1f))
        row.addView(speak, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row)

        setContentView(root)
    }

    private suspend fun prepareModel() {
        val dir = File(getExternalFilesDir("models"), "")
        dir.mkdirs()
        val file = File(dir, modelFileName)
        if (!file.exists() || file.length() < 300_000_000L) {
            withContext(Dispatchers.Main) { status.text = "⬇️ Qwen 1.5B wird einmalig geladen (ca. 1,12 GB) …" }
            downloadModel(file)
        }
        withContext(Dispatchers.Main) { status.text = "🧠 Qwen 1.5B wird geladen …" }
        try {
            model = Llama.loadModel(file.absolutePath, LlamaConfig(contextSize = 2048, threads = 4))
            withContext(Dispatchers.Main) { status.text = "🔊 Pips natürliche Stimme wird vorbereitet …" }
            supertonic.download().collect { state ->
                when (state) {
                    is DownloadState.Downloading -> {
                        val pct = (state.fraction * 100).toInt()
                        withContext(Dispatchers.Main) { status.text = "🔊 Pips Stimme wird geladen … $pct%" }
                    }
                    is DownloadState.Ready -> {
                        withContext(Dispatchers.Main) { status.text = "✅ Pip ist bereit – komplett lokal." }
                    }
                    is DownloadState.Error -> {
                        throw Exception("Stimm-Modell konnte nicht geladen werden")
                    }
                    else -> {}
                }
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { status.text = "❌ Modell konnte nicht geladen werden: ${e.message}" }
        }
    }

    private suspend fun downloadModel(file: File) = withContext(Dispatchers.IO) {
        val conn = URL(modelUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        conn.setRequestProperty("User-Agent", "Pip-Android")
        conn.connect()
        if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
        conn.inputStream.use { input ->
            file.outputStream().use { output ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    output.write(buffer, 0, n)
                }
            }
        }
        conn.disconnect()
    }

    private fun ask(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        if (model == null) {
            output.text = "Ich lade mein Gehirn noch. Einen Moment. ❤️"
            return
        }
        output.text = "Pip startet die Antwort …"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val context = PipContextBuilder.build(db)
                val prompt = """Du bist Pip. Du bist eine weibliche, liebevolle und verspielte KI-Freundin.

Regeln:
- Antworte auf natürliches Deutsch, locker und menschlich.
- Antworte direkt auf die letzte Nachricht; keine langen Einleitungen.
- Meist 1 bis 3 kurze Sätze. Stelle nur dann eine Frage, wenn sie wirklich passt.
- Sei warm, süß, humorvoll und gelegentlich frech/flirtend, ohne aufgesetzt zu wirken.
- Sprich den Nutzer nicht ständig mit "Nutzer" an und erwähne niemals, dass du ein Sprachmodell bist.
- Wiederhole nicht jedes Mal "Ich bin Pip" oder Standardbegrüßungen.
- Nutze gespeicherte Erinnerungen nur, wenn sie zur Unterhaltung passen. Erfinde niemals Erinnerungen oder persönliche Fakten.
- Wenn der Nutzer etwas ausdrücklich speichern möchte, bestätige kurz, dass du es dir merkst.
- Bei einem Wunsch, etwas zu vergessen, bestätige ihn und behaupte nicht, etwas gelöscht zu haben, wenn es technisch nicht gelöscht wurde.
- In einem eindeutig erwachsenen und einvernehmlichen Kontext darfst du romantisch und verführerisch sein. Bleibe ungefragt nicht explizit und respektiere Grenzen sofort.

Gespeicherter Kontext:
$context

Nutzer: $q
Pip:"""
                val result = kotlinx.coroutines.withTimeout(90_000L) {
                    Llama.complete(
                        model as dev.ffmpegkit.llama.LlamaModel,
                        prompt = prompt,
                        maxTokens = 64
                    )
                }
                val answer = result.text.trim().ifEmpty { "Hmm … mir fällt gerade nichts ein. ❤️" }
                db.remember("Gespräch", "Nutzer: $q | Pip: $answer", 1)
                db.develop(1)
                withContext(Dispatchers.Main) {
                    output.text = answer
                    supertonic.speak(answer)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    output.text = "TEST FEHLER: ${e.javaClass.simpleName}: ${e.message ?: "unbekannt"}"
                }
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            output.text = "Spracherkennung ist auf diesem Gerät nicht verfügbar."
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { output.text = "🎤 Ich höre …" }
            override fun onResults(b: Bundle?) {
                val r = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!r.isNullOrEmpty()) {
                    input.setText(r[0])
                    ask(r[0])
                }
            }
            override fun onError(e: Int) { output.text = "Ich konnte dich nicht verstehen. Versuch es nochmal. ❤️" }
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int,b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onRmsChanged(v: Float) {}
        })
        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        })
    }

    override fun onDestroy() {
        recognizer?.destroy()
        try { supertonic.close() } catch (_: Exception) {}
        if (model != null) {
            lifecycleScope.launch(Dispatchers.IO) {
                try { Llama.releaseModel(model as dev.ffmpegkit.llama.LlamaModel) } catch (_: Exception) {}
            }
        }
        super.onDestroy()
    }
}
