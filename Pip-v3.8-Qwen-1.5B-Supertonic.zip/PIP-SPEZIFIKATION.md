# Pip v3.8

- Lokales Sprachmodell: Qwen2.5-1.5B-Instruct GGUF, Q4_K_M
- Modellgröße: ca. 1,12 GB laut offiziellem Qwen-Hugging-Face-Modell
- Lokale llama.cpp-Inferenz
- Kontext 2048, 4 CPU-Threads
- Pip-Persönlichkeit, Gedächtnis und Beziehung aktiv
- Supertonic 3 TTS, deutsche Stimme F2
- Deutsche On-Device-Spracherkennung
