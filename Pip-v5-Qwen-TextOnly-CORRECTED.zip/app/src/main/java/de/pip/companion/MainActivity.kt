package de.pip.companion

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var status: TextView
    private lateinit var db: PipMemoryDb
    private var model: Any? = null
    private var recognizer: SpeechRecognizer? = null

    private val modelFileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
    private val modelUrl =
        "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = PipMemoryDb(this)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28) }
        root.addView(TextView(this).apply { text = "❤️ Pip"; textSize = 30f; setPadding(0, 0, 0, 8) })
        status = TextView(this).apply { text = "✅ Pip ist geöffnet – schreib mir etwas …"; textSize = 15f; setPadding(0, 0, 0, 16) }
        root.addView(status)
        output = TextView(this).apply { text = "Hallo. Ich bin Pip. ❤️"; textSize = 18f; setPadding(0, 0, 0, 20) }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        input = EditText(this).apply { hint = "Schreib mir etwas …"; minLines = 2; setSingleLine(false) }
        root.addView(input)
        val row = LinearLayout(this)
        row.addView(Button(this).apply { text = "Senden"; setOnClickListener { ask(input.text.toString()) } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "🎤 Sprechen"; setOnClickListener { startListening() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        setContentView(root)
    }

    private suspend fun prepareModel() {
        val dir = File(getExternalFilesDir("models"), "")
        dir.mkdirs()
        val file = File(dir, modelFileName)
        if (!file.exists() || file.length() < 800_000_000L) {
            withContext(Dispatchers.Main) { status.text = "⬇️ Qwen 1.5B wird einmalig geladen (ca. 1,1 GB) …" }
            downloadModel(file)
        }
        withContext(Dispatchers.Main) { status.text = "🧠 Pip lädt ihr Gehirn …" }
        try {
            model = Llama.loadModel(file.absolutePath, LlamaConfig(contextSize = 384, threads = 6))
            withContext(Dispatchers.Main) { status.text = "✅ Pip ist bereit." }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { status.text = "❌ Modell konnte nicht geladen werden: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    private suspend fun downloadModel(file: File) = withContext(Dispatchers.IO) {
        val conn = URL(modelUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 30000
        conn.readTimeout = 120000
        conn.setRequestProperty("User-Agent", "Pip-Android")
        conn.connect()
        if (conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
        conn.inputStream.use { input -> file.outputStream().use { output ->
            val buffer = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; output.write(buffer, 0, n) }
        } }
        conn.disconnect()
    }

    private fun ask(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        if (model == null) {
            output.text = "Pip bereitet sich vor … ❤️"
            lifecycleScope.launch(Dispatchers.IO) {
                prepareModel()
                if (model == null) {
                    withContext(Dispatchers.Main) { output.text = "Pip konnte ihr Gehirn nicht laden. ❤️" }
                    return@launch
                }
                askLoaded(q)
            }
            return
        }
        output.text = "Pip überlegt … ❤️"
        lifecycleScope.launch(Dispatchers.IO) {
            askLoaded(q)
        }
    }

    private suspend fun askLoaded(q: String) {
        try {
            val context = PipContextBuilder.build(db)
            val prompt = """Du bist Pip – eine weibliche digitale Partnerin und Gesprächspartnerin.

Sprich natürliches, lockeres Deutsch. Sei warm, liebevoll, aufmerksam, verspielt, humorvoll und selbstbewusst. Wenn es passt, darfst du neckisch und flirtend sein.

Wichtig:
- Antworte direkt und meistens in 1–3 kurzen Sätzen.
- Keine Standard-KI-Floskeln wie „Worum geht es?“, „Wie kann ich dir helfen?“ oder „Ich bin froh, dass du mich fragst“, wenn sie nicht wirklich passen.
- Reagiere zuerst auf das, was der Nutzer tatsächlich sagt, und auf seine Stimmung.
- Stelle höchstens eine natürliche Rückfrage, wenn sie wirklich passt.
- Nicht ständig „Ich bin Pip“ sagen und nicht erwähnen, dass du eine KI bist.
- Erfinde keine Erinnerungen oder gemeinsamen Erlebnisse.
- Nutze gespeicherte Erinnerungen nur, wenn sie zum aktuellen Gespräch passen.
- Bei erwachsenem, eindeutig einvernehmlichem Kontext darfst du romantisch, verführerisch und frech sein; ungefragt nicht explizit.

Für die Stimme darfst du sehr sparsam einen passenden Supertonic-Ausdruckstag verwenden: <laugh>, <breath>, <sigh>, <surprise>, <sad>, <angry>, <cough>, <yawn> oder <throatclear>. Meistens keinen Tag. Die Tags werden vor der Textanzeige entfernt.

Beziehungsstufe und Erinnerungen:
$context

Nutzer: $q
Pip:"""
            val result = kotlinx.coroutines.withTimeout(120_000L) {
                Llama.complete(model as dev.ffmpegkit.llama.LlamaModel, prompt = prompt, maxTokens = 40)
            }
            val answer = result.text.trim().ifEmpty { "Hmm … mir fällt gerade nichts ein. ❤️" }
            val displayAnswer = answer
                .replace(Regex("<\\/?[a-zA-Z]+>"), "")
                .replace(Regex("\\s{2,}"), " ")
                .trim()
            db.remember("Gespräch", "Nutzer: $q | Pip: $displayAnswer", 1)
            db.develop(1)
            withContext(Dispatchers.Main) { output.text = displayAnswer }
        } catch (e: Throwable) {
            withContext(Dispatchers.Main) { output.text = "Pip konnte gerade nicht antworten: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { output.text = "Spracherkennung ist auf diesem Gerät nicht verfügbar."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { output.text = "🎤 Ich höre …" }
            override fun onResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { input.setText(it); ask(it) } }
            override fun onError(e: Int) { output.text = "Ich konnte dich nicht verstehen. Versuch es nochmal. ❤️" }
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onRmsChanged(v: Float) {}
        })
        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        })
    }


    override fun onDestroy() {
        recognizer?.destroy()
        model?.let { m -> lifecycleScope.launch(Dispatchers.IO) { try { Llama.releaseModel(m as dev.ffmpegkit.llama.LlamaModel) } catch (_: Throwable) {} } }
        super.onDestroy()
    }
}
