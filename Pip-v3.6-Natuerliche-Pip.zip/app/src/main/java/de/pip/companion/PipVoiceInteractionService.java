package de.pip.companion;
import android.service.voice.VoiceInteractionService;
public class PipVoiceInteractionService extends VoiceInteractionService {}
