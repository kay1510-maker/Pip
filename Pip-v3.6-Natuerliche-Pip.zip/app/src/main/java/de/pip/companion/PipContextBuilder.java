package de.pip.companion;
public final class PipContextBuilder {
    public static String build(PipMemoryDb db){
        return db.context(12);
    }
}
