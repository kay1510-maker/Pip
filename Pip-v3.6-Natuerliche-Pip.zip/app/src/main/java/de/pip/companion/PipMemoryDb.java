package de.pip.companion;
import android.content.*;
import android.database.sqlite.*;
import android.database.Cursor;

public class PipMemoryDb extends SQLiteOpenHelper {
    public PipMemoryDb(Context c){super(c,"pip_memory.db",null,1);}
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT,content TEXT,importance INTEGER,created INTEGER)");
        db.execSQL("CREATE TABLE relationship(id INTEGER PRIMARY KEY,closeness INTEGER,stage TEXT)");
        db.execSQL("INSERT INTO relationship VALUES(1,0,'Kennenlernen')");
    }
    public void onUpgrade(SQLiteDatabase d,int o,int n){}
    public void remember(String c,String x,int i){
        getWritableDatabase().execSQL("INSERT INTO memories(category,content,importance,created) VALUES(?,?,?,?)",
          new Object[]{c,x,i,System.currentTimeMillis()});
    }
    public String context(int limit){
        StringBuilder s=new StringBuilder();
        Cursor c=getReadableDatabase().rawQuery("SELECT category,content FROM memories ORDER BY importance DESC,created DESC LIMIT ?",
          new String[]{String.valueOf(limit)});
        while(c.moveToNext()) s.append("- ").append(c.getString(0)).append(": ").append(c.getString(1)).append("\n");
        c.close();
        Cursor r=getReadableDatabase().rawQuery("SELECT closeness,stage FROM relationship WHERE id=1",null);
        if(r.moveToFirst()) s.append("Beziehungsstufe: ").append(r.getString(1)).append(" (").append(r.getInt(0)).append("/100)\n");
        r.close();
        return s.toString();
    }
    public void develop(int amount){
        SQLiteDatabase d=getWritableDatabase();
        Cursor c=d.rawQuery("SELECT closeness FROM relationship WHERE id=1",null);
        int x=0;if(c.moveToFirst())x=c.getInt(0);c.close();
        x=Math.max(0,Math.min(100,x+amount));
        String st=x<20?"Kennenlernen":x<40?"Vertraut":x<60?"Nähe":x<80?"Flirtend":"Enge Bindung";
        d.execSQL("UPDATE relationship SET closeness=?,stage=? WHERE id=1",new Object[]{x,st});
    }
}
