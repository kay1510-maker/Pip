# Pip v3.6

Stabile Basis auf Qwen 0.5B GGUF. Verbesserte deutsche Pip-Persönlichkeit, natürlichere kurze Antworten und vorsichtigerer Umgang mit gespeicherten Erinnerungen.
