# Pip v4.7

Stabilitätsversion: Die App öffnet ohne Supertonic-Initialisierung beim Start. Qwen 1.5B wird erst bei der ersten Nachricht geladen. Antworten werden zunächst über Android TTS gesprochen. Supertonic-Code bleibt für die spätere sichere Aktivierung enthalten.
